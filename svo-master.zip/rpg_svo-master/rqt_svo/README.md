run with:

    rosrun rqt_svo rqt_svo

or start `rqt` and display the widget.

If it does not work, try this:

    rm ~/.config/ros.org/rqt_gui.ini
    rqt